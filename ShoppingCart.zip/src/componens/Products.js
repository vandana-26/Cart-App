import React from "react";

export default class Products extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  onAdd = (product) => {
    this.props.handleAddorDelete(product, "add");
  };
  onDelete = (product) => {
    this.props.handleAddorDelete(product, "remove");
  };
  render() {
    return (
      <div>
        {this.props.product.map((item, i) => {
          console.log(item);
          return (
            <div class="productClass">
              <h3>{item.ProductName}</h3>
              <input
                type="button"
                name="addButton"
                value="Add"
                onClick={() => this.onAdd(item)}
              />
              <input
                type="button"
                name="deleteButton"
                value="Delete"
                onClick={() => this.onDelete(item)}
              />
            </div>
          );
        })}
      </div>
    );
  }
}
