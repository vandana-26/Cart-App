import React from "react";

export default class Products extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div>
        <h2>Your Cart</h2>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
        <tbody>
          {
          this.props.cart.items.map((cartItem,index) =>{
            if(cartItem.cartQuantity > 0)
    return(<tr>
              <td>{cartItem.productNam}</td>
              <td>{cartItem.cartQuantity}</td>
              </tr>
    )
            
        })
      }
       </tbody>
      </table>
      </div>
    );
  }
}
