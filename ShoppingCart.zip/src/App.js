import "./styles.css";
import React from "react";
import Products from "./componens/Products";
import Carts from "./componens/Carts";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    const products = [...ProductItems].map((product, index) => {
      product.id = index + 1;
      product.cartQuantity = 0;
      return product;
    });
    this.state = {
      products,
      cart: {
        items: []
      }
    };
  }
  handleAddorDelete = (product, action) => {
    if (action === "add") {
      let items = [...this.state.cart.items];
      let isItemExist = items.filter((i) => i.id === product.id).length > 0;
      if (isItemExist) {
        const newItems = items.map((i) => {
          if (i.id === product.id) {
            i.cartQuantity = i.cartQuantity + 1;
          }
          return i;
        });
        this.setState({
          cart: {
            items: newItems
          }
        });
      } else {
        product.cartQuantity = 1;
        this.state.cart.items.push(product);
        this.setState({
          cart: {
            items: items
          }
        });
      }
    } else if (action === "remove") {
      let items = [...this.state.cart.items];
      const newItems = items
        .map((i) => {
          if (i.id === product.id) {
            i.cartQuantity = i.cartQuantity - 1;
          }
          return i;
        })
        .filter((i) => i.cartQuantity > 0);
      this.setState({
        cart: {
          items: newItems
        }
      });
    }
  };
  render() {
    return (
      <div className="App">
        <h1>Buy Adobe Product</h1>
        <Products
          product={this.state.products}
          handleAddorDelete={this.handleAddorDelete}
        />
        <Carts cart = {this.state.cart}/>
      </div>
    );
  }
}

const ProductItems = [
  {
    ProductName: "CloudDeveloperApp",
    price: 1460.5
  },
  {
    ProductName: "Item1",
    price: 1460.5
  },
  {
    ProductName: "Premiere Rush",
    price: 1460.5
  },
  {
    ProductName: "Item3",
    price: 1460.5
  },
  {
    ProductName: "Item4",
    price: 1460.5
  }
];
